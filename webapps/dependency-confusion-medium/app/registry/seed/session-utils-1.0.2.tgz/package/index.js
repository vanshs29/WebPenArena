function isSessionFresh(issuedAtSeconds, maxAgeSeconds) {
  return Date.now() / 1000 - issuedAtSeconds < maxAgeSeconds;
}

module.exports = { isSessionFresh };
